# LEAP_ProjectFinal

Hey Guys this kind of simple which template from colorlib, I almost made neccessary changes the remaining ones are adjufying css well for making better front-end
and back-end of, so we can share ideas for which easy and afst way to use for back-end please.

for pushing any update please make brance and then marge after to avoing conflict from  different local repostory
